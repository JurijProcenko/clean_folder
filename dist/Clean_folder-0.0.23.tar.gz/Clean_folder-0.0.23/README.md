""" Garbadge sorter
Take one argument - folder for sorting.
He's sorting and moving files to folders:
images, documents, video, audio, archives

"""